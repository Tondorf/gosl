#ifndef __IMAGE
#define __IMAGE

char *readImage(const char* filename, int *cols, int *rows, int *imgz);

#endif
