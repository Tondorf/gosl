#ifndef __MISC
#define __MISC

struct prog_info {
	int mode;
	int client_offset;
	int port;
	int fps;
	int width;
	char *filename;
} prog_info;

#endif

